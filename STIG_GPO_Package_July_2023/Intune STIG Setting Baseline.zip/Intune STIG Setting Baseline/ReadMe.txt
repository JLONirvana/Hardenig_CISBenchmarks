WARNING
-------

It must be noted that the Intune policies provided should be evaluated in a representative test environment before implementation within production environments. The extensive variety of environments makes it impossible to test these MEM policies for all potential enterprise and software configurations. For most environments, failure to test before implementation may lead to a loss of required functionality.


INTRODUCTION
------------

This package contains JSON backup exports. It is to provide enterprise administrators the supporting Intune policies and related files to aid them in the deployment of Intune within their enterprise to meet STIG settings. Administrators are expected to fully test policies in test environments prior to live production deployments.

Administrators can locate the documented STIG compliance in corresponding STIG Checklist file contained within the DISA STIG GPO Package (Support Files/Checklist Files). The checklist file provide the appropriate device configuration profile setting is located i.e. Endpoint Security baseline, Administrative template, Custom profile, or Endpoint protection.


MAINTENANCE
-----------

This package will be updated with each quarterly release of STIG updates. If a targeted STIG within package is released out of cycle, the package will be updated accordingly. Additional if a new STIG is targeted to provide a supporting policy, the package will be updated to include JSON backup.

The intial release of DISA Intune STIG Package is targeted for Windows 10/11 systems. Mobile devcie management is out of scope at this time. Administrators may find iOS, macOS and Android device configurations profiles within the corresponding STIG downloads on CyberMIL.


USAGE
-----

This package is to be used to assist administrators implementing STIG settings within their environment. The administrator must fully test policies in test environments prior to live production deployments. The policies provided contain most applicable and restrictive STIG settings contained in STIG files. 

The Microsoft 365 Administrative Template profile will apply to all Microsoft Office 2016, Microsoft Office 2019, and M365 Apps.

Administrators must apply the security baseline and each device configuration profile to meet STIG compliance. Failure to apply all device profiles will result in an incomplete application of intended STIG configurations.

In Co-management environment, administrators must configure the appropriate workload to apply Intune policies. It is not intended this package be a deployment guide for administrators.

January 2023
Inclusion of Settings Catalog profiles. The settings catalog are intended to support environments in co-management and not all workloads are migrated. The settings catalog are near "all-inclusive" configuration of Windows STIG requirements. In environments where the MS Security baselines are being used there is no need to migrate to catalog settings as existing MS Security Baseline profile layered with the appropropriate devcie configuration administrative template, endpoint security and custom profile will achieved STIG compliance.

Added device configuration profiles Edge, Chrome, and Firefox for macOS to meet STIG requirements.

Added PowerShell scripts to assist in completng configurations to meet STIG requirements where no configuration item is available with native tools.

Third-party administrative template profiles will require import of the ADMX files. The ADMX files can be located under the ADMX Template directory in root of STIG Baseline. Administrative template profiles are intended to phase out the need for custom OMA-URI profiles

April 2023

Addition of Sample USB device control policies. Provide both custom profile and Attack surface reduction policies. Policies are configured to default allow and blocks all removable storage devices. WARNING: CDROM devices are block with sample XML files provided. Device control group leverage device serial number for approved devices.

Addition of AVD MDE scan exclusions. Administrator must update storage account information for individual environments.


KNOWN ISSUES
------------

Windows 10 Admnistrative Template Device Configuration Profile - DoD Windows 10 STIG vXrX Admnistrative Templates
STIG ID WN10-CC-000052 Windows 10 must be configured to prioritize ECC Curve with longer key lengths first setting has been removed from JSON file. Administrators must configure STIG ID WN10-CC-000052 setting after importing device configuration profile in to environment. 

The checklist files are located in DISA STIG GPO Package.